#Data of the KIT libraries

##Schema

1. id
* date (day time)
* Lesesaal Geisteswissenschaften
* Lesesaal Technik
* Lesesaal Wiwi/Info
* Lesesaal Naturwissenschaften
* Lehrbuchsammlung
* Fachbibliothek Physik
* Fachbibliothek Informatik
* Fakultätsbibliothek Architektur
* KIT-Bib Campus Nord
* Fachbibliothek Hochschule Karlsruhe
* Theater Bibliothek
* Fachbilbiothek Wiwi
* Fachbibliothek Chemie
* Fachbibliothek Mathematik

Numbers represent the occupied places during this moment.

##Problems

As the whole system is based on registered devices in the wireless network, the data may have some minor inaccuracies due to people moving next to the building.

